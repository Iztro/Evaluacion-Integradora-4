package Cuenta;

import java.util.ArrayList;
import java.util.List;

import Transaccion.Deposito;
import Transaccion.Retiro;
import Transaccion.Transaccion;
import Transaccion.Transferencia;
import calculaMoneda.Moneda;
import calculaMoneda.MonedaPesoChileno;
import persona.Usuario;

public class CuentaBancaria implements IAccionesCuentaBancaria{
	private Usuario usuario;
	private List<Transaccion> listaTransacciones;
	private int numCuenta;
	private double saldo;
	private Moneda moneda;
	
	public CuentaBancaria(Usuario usuario) {
		
		this.moneda = new MonedaPesoChileno();
		this.usuario = usuario;
		this.listaTransacciones = new ArrayList<>();
		this.numCuenta = (int) (Math.random() * 37373737 + 37);
		this.saldo = 0.000;
	}

	public Usuario getUsuario() {
		return usuario;
	}

	public void setUsuario(Usuario usuario) {
		this.usuario = usuario;
	}

	public List<Transaccion> getListaTransacciones() {
		return listaTransacciones;
	}

	public void setListaTransacciones(List<Transaccion> listaTransacciones) {
		this.listaTransacciones = listaTransacciones;
	}

	public int getNumCuenta() {
		return numCuenta;
	}

	public void setNumCuenta(int numCuenta) {
		this.numCuenta = numCuenta;
	}

	public double getSaldo() {
		return saldo;
	}

	public void setSaldo(double saldo) {
		this.saldo = saldo;
	}
	
	
	public Moneda getMoneda() {
		return moneda;
	}

	public void setMoneda(Moneda moneda) {
		this.moneda = moneda;
	}

	@Override
	public void depositarMonto(double monto) {
		// TODO Auto-generated method stub
		this.saldo += monto;
		this.listaTransacciones.add(new Deposito(monto, "Deposito"));
		System.out.println("Deposito Exitoso");
	}

	@Override
	public void transferirMonto(double monto, CuentaBancaria cuentaDestino) {
		// TODO Auto-generated method stub
		if (this.saldo > monto) {
            this.saldo -= monto;
            cuentaDestino.saldo += monto;
            System.out.println("Transferencia Exitosa");
            this.listaTransacciones.add(new Transferencia(monto, "Transferencia"));
            return;
		}
		else {
			System.out.println("Saldo Insuficiente");
		}
	}

	@Override
	public void retirarMonto(double monto) {
		// TODO Auto-generated method stub
		if (this.saldo > monto) {
            this.saldo -= monto;
            
            System.out.println("Retiro Exitoso");
            this.listaTransacciones.add(new Retiro(monto, "Retiro"));
            return;
		}
		else {
			System.out.println("Saldo Insuficiente");
		}
		
	}
	
	

}
