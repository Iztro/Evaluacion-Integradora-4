package Transaccion;

public class Transferencia extends Transaccion{

	public Transferencia(double monto, String tipoTransaccion) {
		super(monto, tipoTransaccion);
		// TODO Auto-generated constructor stub
	}

}
