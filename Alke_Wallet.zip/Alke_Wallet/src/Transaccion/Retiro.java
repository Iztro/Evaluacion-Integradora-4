package Transaccion;

public class Retiro extends Transaccion{

	public Retiro(double monto, String tipoTransaccion) {
		super(monto, tipoTransaccion);
		// TODO Auto-generated constructor stub
	}

}
