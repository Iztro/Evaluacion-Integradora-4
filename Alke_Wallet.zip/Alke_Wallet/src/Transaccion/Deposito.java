package Transaccion;

public class Deposito extends Transaccion{

	public Deposito(double monto, String tipoTransaccion) {
		super(monto, tipoTransaccion);


	}

}
