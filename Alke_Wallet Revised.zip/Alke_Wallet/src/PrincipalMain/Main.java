package PrincipalMain;

import java.util.Scanner;

import Cuenta.CuentaBancaria;
import Transaccion.Transaccion;
import persona.Usuario;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		System.out.println("Bienvenido a Our Wallet");
		Scanner scanner = new Scanner(System.in);
		
		//por consola preguntará lo marcado en comillas dobles
		
		System.out.println("Ingrese su nombre");
		 String nombre= scanner.next();
		 
		 System.out.println("Ingrese su correo");
		 String correo= scanner.next();
		 
		 System.out.println("Ingrese su contraseña");
		 String contrasena= scanner.next();
		 
		Usuario usuario = new Usuario(nombre, correo, contrasena);
		
		CuentaBancaria cuentaBancaria = new CuentaBancaria(usuario);
		usuario.setCuentaBancaria(cuentaBancaria);
		
		System.out.println("El nombre es  " + usuario.getNombre());
		System.out.println("El correo es  " + usuario.getCorreo());
		
		System.out.println("La cuenta Bancaria es " + usuario.getCuentaBancaria().getNumCuenta());
		System.out.println("El saldo es " + usuario.getCuentaBancaria().getSaldo());
		System.out.println("La moneda Bancaria es " + usuario.getCuentaBancaria().getMoneda().getSimbolo());
		
		System.out.println("Ingrese los datos de cuenta que recibirá la transferencia");
		Usuario usuario2 = new Usuario("Aldebaran", "aldebaran@mail.com", "sssss");
		
		System.out.println("¿Cuanto va a depositar a OUR cuenta?");
		double monto2 = scanner.nextDouble();
		usuario.getCuentaBancaria().depositarMonto(monto2);
		System.out.println("----------Transacciones-----------");
		for(Transaccion transaccion: usuario.getCuentaBancaria().getListaTransacciones()) {
			System.out.println("Fecha : "+ transaccion.getFecha() + " Tipo de Transaccion: " + transaccion.getTipoTransaccion() + " Monto: " + transaccion.getMonto());
		}
	
		
		scanner.close();

	}

}
