package calculaMoneda;

public class MonedaEuro implements Moneda{

	@Override
	public String getSimbolo() {
		// TODO Auto-generated method stub
		return "EUR";
	}

	@Override
	public double getFactorConversion() {
		// TODO Auto-generated method stub
		return 0.85;
	}

	@Override
	public double convertir(double cantidad, Moneda otraMoneda) {
		// TODO Auto-generated method stub
		return cantidad * otraMoneda.getFactorConversion();
	}

}
