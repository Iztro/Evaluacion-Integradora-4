package calculaMoneda;

public class MonedaPesoChileno implements Moneda{

	@Override
	public String getSimbolo() {
		// TODO Auto-generated method stub
		return "$";
	}

	@Override
	public double getFactorConversion() {
		// TODO Auto-generated method stub
		return 960;
	}

	@Override
	public double convertir(double cantidad, Moneda otraMoneda) {
		// TODO Auto-generated method stub
		return cantidad * otraMoneda.getFactorConversion();
	}

}
