package test;

import static org.junit.Assert.*;
import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.Test;
import Cuenta.CuentaBancaria;
import persona.Usuario;
import calculaMoneda.MonedaDolar;
import calculaMoneda.MonedaPesoChileno;

public class CuentaBancariaTest {
    
    @Test
    public void testDeposito() {
        Usuario usuario = new Usuario("Prueba", "prueba@mail.com", "password");
        CuentaBancaria cuenta = new CuentaBancaria(usuario);
        cuenta.depositarMonto(1000.0);
        assertEquals(1000.0, cuenta.getSaldo(), 0.01);
    }

    @Test
    public void testRetiro() {
        Usuario usuario = new Usuario("Prueba", "prueba@mail.com", "password");
        CuentaBancaria cuenta = new CuentaBancaria(usuario);
        cuenta.depositarMonto(1000.0);
        cuenta.retirarMonto(500.0);
        assertEquals(500.0, cuenta.getSaldo(), 0.01);
    }

    @Test(expected = IllegalArgumentException.class)
    public void testTransferenciaInsuficienteSaldo() {
        Usuario usuario1 = new Usuario("Prueba1", "prueba1@mail.com", "password");
        Usuario usuario2 = new Usuario("Prueba2", "prueba2@mail.com", "password");
        CuentaBancaria cuenta1 = new CuentaBancaria(usuario1);
        CuentaBancaria cuenta2 = new CuentaBancaria(usuario2);
        cuenta1.depositarMonto(100000.0);
        cuenta1.transferirMonto(1500.0, cuenta2);  // Esto debería lanzar una excepción.
    }

    @Test
    public void testConversionMoneda() {
        MonedaDolar dolar = new MonedaDolar();
        MonedaPesoChileno pesoChileno = new MonedaPesoChileno();
        double montoConvertido = dolar.convertir(100, pesoChileno);
        assertEquals(96000.0, montoConvertido, 0.01);
    }
    
    @Test
    public void testDepositoMontoNegativo() {
        Usuario usuario = new Usuario("Test", "test@example.com", "pass");
        CuentaBancaria cuenta = new CuentaBancaria(usuario);
        try {
            cuenta.depositarMonto(-100.0);
            fail("No se lanzó una excepción para depósito negativo");
        } catch (IllegalArgumentException e) {
            assertEquals("No se puede depositar un monto negativo", e.getMessage());
        }
    }

    @Test
    public void testRetiroMontoCero() {
        Usuario usuario = new Usuario("Test", "test@example.com", "pass");
        CuentaBancaria cuenta = new CuentaBancaria(usuario);
        cuenta.depositarMonto(1000.0);
        cuenta.retirarMonto(0);
        assertEquals(1000.0, cuenta.getSaldo(), 0.01, "El saldo no debe cambiar al intentar retirar 0");
    }

    @Test
    public void testTransferenciaMontoExcesivo() {
        Usuario usuario1 = new Usuario("User1", "user1@example.com", "pass1");
        Usuario usuario2 = new Usuario("User2", "user2@example.com", "pass2");
        CuentaBancaria cuenta1 = new CuentaBancaria(usuario1);
        CuentaBancaria cuenta2 = new CuentaBancaria(usuario2);
        cuenta1.depositarMonto(500.0);
        try {
            cuenta1.transferirMonto(1000.0, cuenta2);
            fail("No se lanzó una excepción al transferir un monto mayor al saldo");
        } catch (IllegalArgumentException e) {
            assertEquals("Saldo insuficiente para la transferencia", e.getMessage());
        }
    }
}