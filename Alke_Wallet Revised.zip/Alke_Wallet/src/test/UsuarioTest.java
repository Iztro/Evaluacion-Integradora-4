package test;

import static org.junit.Assert.*;
import org.junit.Test;
import persona.Usuario;
import Cuenta.CuentaBancaria;
import calculaMoneda.Moneda;
import calculaMoneda.MonedaDolar;

public class UsuarioTest {

    @Test
    public void testCreacionUsuario() {
        Usuario usuario = new Usuario("Deneb D'Empress", "deneb@example.com", "securepassword");
        assertEquals("Deneb D'Empress", usuario.getNombre());
        assertEquals("deneb@example.com", usuario.getCorreo());
        assertEquals("securepassword", usuario.getContrasena());
    }

    @Test
    public void testSetCuentaBancaria() {
        Usuario usuario = new Usuario("Deneb D'Empress", "deneb@example.com", "securepassword");
        CuentaBancaria cuenta = new CuentaBancaria(usuario);
        usuario.setCuentaBancaria(cuenta);
        assertNotNull(usuario.getCuentaBancaria());
    }

    @Test
    public void testConversiónInvalida() {
        Moneda ficticia = new Moneda() {
            @Override
            public String getSimbolo() { return "FCT"; }
            @Override
            public double getFactorConversion() { return 0; } // Factor no válido.
            @Override
            public double convertir(double cantidad, Moneda otraMoneda) {
                if (getFactorConversion() == 0 || otraMoneda.getFactorConversion() == 0)
                    throw new IllegalArgumentException("Tasa de conversión inválida");
                return cantidad * getFactorConversion() / otraMoneda.getFactorConversion();
            }
        };
        MonedaDolar dolar = new MonedaDolar();

        try {
            ficticia.convertir(100, dolar);
            fail("No se lanzó una excepción con una tasa de conversión inválida");
        } catch (IllegalArgumentException e) {
            assertEquals("Tasa de conversión inválida", e.getMessage());
        }
}
}

