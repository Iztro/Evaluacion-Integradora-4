package Transaccion;

import java.util.Date;

public class Transaccion {
	private Date fecha;
	private int id;
	private double monto;
	private String tipoTransaccion;
	
	public Transaccion(double monto, String tipoTransaccion) {
		
		this.tipoTransaccion = tipoTransaccion;
		this.fecha = new Date();
		this.id = (int) (Math.random() * 1000 + 1);
		this.monto = monto;
	}
	public Date getFecha() {
		return fecha;
	}
	public void setFecha(Date fecha) {
		this.fecha = fecha;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public double getMonto() {
		return monto;
	}
	public void setMonto(double monto) {
		this.monto = monto;
	}
	public String getTipoTransaccion() {
		return tipoTransaccion;
	}
	public void setTipoTransaccion(String tipoTransaccion) {
		this.tipoTransaccion = tipoTransaccion;
	}
	

}
