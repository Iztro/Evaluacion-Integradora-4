package Cuenta;

public interface IAccionesCuentaBancaria {
	public void depositarMonto(double monto);
	public void transferirMonto(double monto, CuentaBancaria cuentaDestino);
	public void retirarMonto(double monto);

	
}
