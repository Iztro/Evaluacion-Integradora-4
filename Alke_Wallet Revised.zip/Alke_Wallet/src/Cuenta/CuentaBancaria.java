package Cuenta;

import java.util.ArrayList;
import java.util.List;
import Transaccion.Deposito;
import Transaccion.Retiro;
import Transaccion.Transaccion;
import Transaccion.Transferencia;
import calculaMoneda.Moneda;
import calculaMoneda.MonedaPesoChileno;
import persona.Usuario;

// Clase que implementa la interfaz de acciones de cuenta bancaria, gestionando la lógica de negocio para operaciones bancarias.
public class CuentaBancaria implements IAccionesCuentaBancaria {
    private Usuario usuario;
    private List<Transaccion> listaTransacciones;
    private int numCuenta;
    private double saldo;
    private Moneda moneda;

    // Constructor de la clase que inicializa un usuario y establece el tipo de moneda por defecto.
    public CuentaBancaria(Usuario usuario) {
        this.setMoneda(new MonedaPesoChileno()); // Asigna MonedaPesoChileno como moneda por defecto.
        this.setUsuario(usuario);
        this.listaTransacciones = new ArrayList<>();
        this.setNumCuenta((int) (Math.random() * 37373737 + 37)); // Genera un número de cuenta aleatorio.
        this.saldo = 0.0; // Inicializa el saldo a 0.
    }

    /**
	 * @return the numCuenta
	 */
	public int getNumCuenta() {
		return numCuenta;
	}

	/**
	 * @param numCuenta the numCuenta to set
	 */
	public void setNumCuenta(int numCuenta) {
		this.numCuenta = numCuenta;
	}

	/**
	 * @return the usuario
	 */
	public Usuario getUsuario() {
		return usuario;
	}

	/**
	 * @param usuario the usuario to set
	 */
	public void setUsuario(Usuario usuario) {
		this.usuario = usuario;
	}

	// Agrega un monto al saldo de la cuenta y registra la transacción.
    @Override
    public void depositarMonto(double monto) {
        this.saldo += monto; // Añade el monto al saldo actual.
        this.listaTransacciones.add(new Deposito(monto, "Deposito")); // Registra la transacción de depósito.
        System.out.println("Deposito Exitoso");
    }

    /**
	 * @return the moneda
	 */
	public Moneda getMoneda() {
		return moneda;
	}

	/**
	 * @param moneda the moneda to set
	 */
	public void setMoneda(Moneda moneda) {
		this.moneda = moneda;
	}

	// Transfiere un monto de esta cuenta a otra cuenta, si el saldo lo permite.
    @Override
    public void transferirMonto(double monto, CuentaBancaria cuentaDestino) {
        if (this.saldo < monto) {
            System.out.println("Saldo insuficiente para la transferencia");
            throw new IllegalArgumentException("Saldo insuficiente para la transferencia");
        }
        this.saldo -= monto;
        cuentaDestino.saldo += monto;
        this.listaTransacciones.add(new Transferencia(monto, "Transferencia")); // Registra la transacción de transferencia.
        System.out.println("Transferencia Exitosa");
    }

    // Permite retirar un monto de la cuenta si hay saldo suficiente.
    @Override
    public void retirarMonto(double monto) {
        if (this.saldo < monto) {
            System.out.println("Saldo insuficiente para el retiro");
            throw new IllegalArgumentException("Saldo insuficiente para el retiro");
        }
        this.saldo -= monto;
        this.listaTransacciones.add(new Retiro(monto, "Retiro")); // Registra la transacción de retiro.
        System.out.println("Retiro Exitoso");
    }

	public double getSaldo() {
		// TODO Auto-generated method stub
		return 0;
	}

	public Transaccion[] getListaTransacciones() {
		// TODO Auto-generated method stub
		return null;
	}
}


